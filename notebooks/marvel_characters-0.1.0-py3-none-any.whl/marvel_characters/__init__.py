"""Marvel Characters package for analyzing and predicting character survival."""
